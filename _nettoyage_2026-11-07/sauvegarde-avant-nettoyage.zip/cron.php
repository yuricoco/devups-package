<?php

require 'header.php';

$workerCtrl = new WorkersController();

$workerCtrl->work();

// [stickers-9] Passe de reconciliation des cadeaux par sticker (design
// note §6.e) : un balayage de `donate` type='gift', status=0, created_at
// de plus de 15 minutes. Fondee sur l'ETAT, pas sur un worker particulier -
// elle rattrape tout ce qu'un worker perdu, un cadavre en `log` (voir
// GiftDistributor::register()) ou une reinscription manquee auraient
// laisse tomber. Accrochee ICI (cron.php n'est pas dans dclass/, et c'est
// le seul point d'entree deja planifie de ce depot) plutot que dans
// WorkersController::work() - pas touche, lecture seule.
GiftDistributor::reconcileStale();