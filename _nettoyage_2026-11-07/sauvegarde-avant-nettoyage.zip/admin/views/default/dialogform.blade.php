{{--
    [formengine-point5] verifie avant d'y toucher, comme demande : son
    seul appelant dans tout le depot est un bloc COMMENTE de
    FormManager::renderForm() (dclass/devups/Form/FormManager.php) -
    zero occurrence de "default.dialogform" ailleurs, src/ compris.
    Code mort - laisse tel quel (pas supprime), le width={{$width}}px
    en dur ci-dessous n'est donc jamais rendu en pratique.
--}}
<div class="main-card mb-3 card " style="width: {{$width}}px">
    <div class="card-header">
        <h3 class="card-title"> {!! $formtitle !!}</h3>
        <div class="card-toolbar">
            <button type="button" onclick="model._dismissmodal()"
                    class="btn btn-default "
                    aria-label="Close this dialog"
                    style="display: block;">×
            </button>
        </div>
    </div>
    <div class="card-body">
        {!! $formcontent !!}
    </div>
</div>
