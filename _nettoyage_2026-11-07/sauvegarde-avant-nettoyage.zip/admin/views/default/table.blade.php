{{--
    [datatable-point3] seul endroit qui rend l'etat vide d'une datatable -
    appele a la fois par Datatable::render() (chargement de page complet) et
    Datatable::getTableRest() (reponse AJAX de recherche/pagination/tri), qui
    partageaient avant ce chantier deux implementations differentes (render()
    mettait juste une chaine vide, getTableRest() appelait cette vue - mais
    la condition @if($data) etait inversee et la branche @else, la vraie
    table, etait entierement commentee : au mieux rien ne s'affichait, au
    pire "la liste est vide" s'affichait meme quand elle ne l'etait pas).

    $colspan et $searched sont fournis par l'appelant (Datatable.php). Rendu
    comme une ligne de tableau (<tr><td colspan>) et non comme un bloc a
    part : les deux points d'appel injectent ce gabarit a l'interieur d'un
    <tbody> existant (voir templateTable() dans TableTemplateRender.php) -
    un <div> ici casserait la structure table/tbody.
--}}
<tr class="dv_empty_state">
    <td colspan="{{ $colspan }}" class="text-center text-muted" style="padding: 2rem 1rem;">
        @if ($searched)
            {{ t('Aucun résultat pour cette recherche.') }}
        @else
            {{ t('Aucun élément pour l\'instant.') }}
        @endif
    </td>
</tr>
