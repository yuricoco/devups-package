<?php

/**
 * config environment
 * DirectAdmin LOGIN INFORMATION:
 *
 *
 */

const PROJECT_NAME = "Devups TEST";

const dbname = 'devupstest_bd';
const dbuser = 'root';
const dbpassword = '';
const dbhost = 'localhost';
const dbdumper = false;
const dbtransaction = true;

// base url
// in production, replace by "/"
const __v = '4.3';

define('__ip', "");
const __server = 'http://127.0.0.1';
const __env_port = ":3030"; // leave this empty in production
// const __env_port = "/devupstest"; // leave this empty in production
const __env = __server . __env_port . '/';
const __env_front =  'http://localhost:5173/';

const __csrf_origin = "http://localhost:8081,http://localhost:5173,http://localhost:3000,null,https://localhost";

const __vendor_folder = __DIR__ . '/../vendor';
define("__front", __env . 'web/assets/');
const __admin = __env . 'admin/assets/';
const __prod = true;
const __route_cache = false;
const __cache_version = '1.0.3';
// define('__debug', false);
const __default_lang = "fr";
const __lang = 'fr';

/**
 * config toolrad sync
 */
const __project_id = 'devupstuto' . __env_port;
const __toolrad_server = 'https://toolrad.spacekola.com/api/';
const __toolrad_api_key = 'apikey';


const ROOT = __DIR__ . '/../';
const CLASS_EXTEND = ROOT . "dclass/extends";
const UPLOAD_DIR = __DIR__ . '/../uploads/';
const admin_dir = __DIR__ . '/../admin/';
const web_dir = __DIR__ . '/../web/';

const SRC_FILE = __env . 'uploads/';
const CLASSJS = __env . 'dclass/devupsjs/';
const node_modules = __env . 'node_modules/';

const ENTITY = 0;
const VIEW = 1;

const ADMIN = __project_id . '_devups';
const CSRFTOKEN = __project_id . '_csrf_token';
const dv_role_navigation = __project_id . '_navigation';
const dv_role_permission = __project_id . '_permission';

/**
 * NOTIFIACTION DEFINE
 */
const LANG = "lang";
const PREVIOUSPAGE = "previous_page";
const JSON_ENCODE_DEPTH = 512;
const USERAPP = '_app';


/**
 * SMTP DEFINE
 */

const sm_port = '465';
const sm_smtp = 'mail.3ag-edition.com';
const sm_username = 'no-reply@3ag-edition.com';
const sm_password = '{9@H6sbPMClH';
const sm_from = 'no-reply@3ag-edition.com';
const sm_name = PROJECT_NAME;
const sm_smtpsecurity = 'ssl';

/**
 * JWT DEFINE
 */

const jwt_secret_Key  = '68V0zWFrS72GbpPr...fj4v9m3Ti+DXc8OB0gcM=';
const jwt_expire_time  = false; //'+72 hours'

/**
 * FCM DEFINE
 */

const fcm_pair_key  = 'BFwz1RJGK43sFcZaHzC98Swrv0buhKeSMtzYTZXXZsJsig8Ei_Jaizf79QcwavAUbu74qN2LANIGTrQ1LGbAA08';
const fcm_user_id  = 100103663575834667864;
const fcm_project_id  = 'agedition-d60a9';
const fcm_jwt_auth_file  = 'agedition-d60a9-firebase-adminsdk-rrapx-9129846ba8.json';

const cron_token  = 'da39a3ee5e6b4b0...fef95601890afd80709';

// Google API configuration
const GOOGLE_CLIENT_ID = '941624975063-01nqshsml8d9j4rt0c5sg2a9imkml35e.apps.googleusercontent.com';

const GOOGLE_CLIENT_ID_WEB = '941624975063-ej9l0q89krcqpf456img89r96s7if9ug.apps.googleusercontent.com';
const GOOGLE_CLIENT_ID_ANDROID = '941624975063-susvcpv6job90u5jq20f1up9t1su0fgh.apps.googleusercontent.com';
const GOOGLE_CLIENT_ID_IOS = '941624975063-bjreja2qu2hj5cfbnms95msne3ces1uc.apps.googleusercontent.com';
const GOOGLE_CLIENT_SECRET = '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';
const GOOGLE_REDIRECT_URL = 'https://backend.3ag-edition.com/auth/google';

const afropay_api = "https://backend.spacepay.spacekola.com/api";
const afropay_domaine_key = "for a specific domaine within afropay";
const afropay_access_token = "for the user account";

// KOLACOIN_RATE_FCFA ([money-1]) ne vit PLUS ici depuis [money-3] : ce
// fichier n'est JAMAIS charge directement par l'application (seul
// `constante.php`, ignore par git, l'est - celui-ci n'est qu'un gabarit de
// deploiement). Voir config/dependanceInjection.php, seule source
// desormais, suivie par git et chargee sur tout environnement.
// aiMemory/memory_2026-10-19_v1.md.

global $devups_cache;
$devups_cache = [];
