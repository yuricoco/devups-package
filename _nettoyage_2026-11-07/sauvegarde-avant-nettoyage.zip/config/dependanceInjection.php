<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


require __DIR__ . '/constante.php';

/**
 * Taux de conversion kolacoin <-> FCFA, en nombre entier de FCFA par
 * kolacoin ([money-1], 2026-10-14 ; deplace ici par [money-3], meme date).
 *
 * AVANT : onze copies du litteral `10` (Product, Orders, Transaction,
 * Donate, Payment), avec neuf lignes commentees d'une variante abandonnee
 * (`* (11 / 100)`) jamais utilisee.
 *
 * POURQUOI ICI et pas dans `constante.php` ([money-1], corrige par
 * [money-3]) : `constante.php` est ignore par git (`.gitignore:15`) - sur
 * un clone neuf, la constante n'existait nulle part et la premiere
 * insertion de l'une des cinq entites partait en erreur fatale
 * (« Undefined constant »). `constante.prod.php`, lui, n'est JAMAIS charge
 * directement par l'application : c'est un gabarit de deploiement, copie
 * en `constante.php` sur le serveur de production au moment du deploiement
 * - aucun `require` de ce depot ne le cible. CE fichier
 * (`dependanceInjection.php`) est en revanche le SEUL point commun,
 * suivi par git, requis par absolument tout point d'entree qui peut
 * instancier une de ces cinq entites : `header.php` (application) ET
 * `admin/header.php` (back-office) le requierent tous les deux ; seule
 * `admin/login.php` (le formulaire de connexion, qui ne touche aucune
 * entite d'argent) charge `constante.php` sans passer par ici.
 *
 * **C'est desormais la SEULE declaration qui fait foi** - `constante.php`
 * et `constante.prod.php` ne la portent plus, pour eviter toute redeclaration
 * et toute ambiguite sur laquelle des deux ferait foi.
 *
 * Constante PHP, pas une entree `Configuration` : ce taux est lu dans
 * `__insert()` de cinq entites, donc tres souvent - une entree
 * `Configuration` (une requete par lecture) serait un mauvais echange.
 * Et la note de conception des reactions par stickers
 * (`aiMemory/design_2026-10-13_stickers_reactions.md` §3) est explicite :
 * le taux est estampille sur la ligne d'accumulation au moment du cadeau,
 * et s'il changeait un jour, les gains deja acquis ne doivent pas etre
 * reevalues. C'est exactement ce qu'une constante figee au deploiement
 * garantit.
 *
 * Voir aiMemory/memory_2026-10-19_v1.md pour la preuve que ce deplacement
 * ne change aucune valeur calculee (meme nombre, memes lectures).
 */
const KOLACOIN_RATE_FCFA = 10;

//if (__debug)
//    require 'php_ini.php';

if (file_exists(__vendor_folder)) {
    require __vendor_folder . '/autoload.php';
}

require __DIR__ . '/Database.php';

require __DIR__ . '/../admin/generator/TableTemplateRender.php';

require __DIR__ . '/../dclass/devups/Tchutte/Bugmanager.php';
require __DIR__ . '/../dclass/devups/Core.php';
require __DIR__ . '/../dclass/devups/Tchutte/DBAL.php';
require __DIR__ . '/../dclass/devups/Tchutte/DB_dumper.php';
require __DIR__ . '/../dclass/devups/Tchutte/QueryBuilder.php';
require __DIR__ . '/../dclass/devups/Tchutte/Column.php';
require __DIR__ . '/../dclass/devups/Dfile.php';
require __DIR__ . '/../dclass/devups/ScanDir.php';
require __DIR__ . '/../dclass/devups/model/DateTimeTrait.php';
require __DIR__ . '/../dclass/devups/model/ModelSerializer.php';
require __DIR__ . '/../dclass/devups/model/ModelTrait.php';
require __DIR__ . '/../dclass/devups/model/Model.php';
require __DIR__ . '/../dclass/devups/DvupsTranslation.php';
require __DIR__ . '/../dclass/devups/model/EntityCollection.php';
require __DIR__ . '/../dclass/devups/Controller/Controller.php';
require __DIR__ . '/../dclass/devups/Controller/FrontController.php';
require __DIR__ . '/../dclass/devups/Controller/CrudTrait.php';
require __DIR__ . '/../dclass/devups/Genesis.php';
require __DIR__ . '/../dclass/devups/Datatable/Lazyloading.php';
require __DIR__ . '/../dclass/devups/Datatable/Datatable.php';
require __DIR__ . '/../dclass/devups/Datatable/DatatableOverwrite.php';
require __DIR__ . '/../dclass/devups/Datatable/Dbutton.php';
require __DIR__ . '/../dclass/devups/System_prod.php';
require __DIR__ . '/../dclass/devups/UploadFile.php';
require __DIR__ . '/../dclass/devups/model/EntityCore.php';
require __DIR__ . '/../dclass/devups/Form/FormFactory.php';
require __DIR__ . '/../dclass/devups/Form/FormManager.php';
require __DIR__ . '/../dclass/devups/Form/Form.php';
require __DIR__ . '/../dclass/devups/Http/Request.php';
require __DIR__ . '/../dclass/devups/Http/Response.php';
require __DIR__ . '/../dclass/devups/Http/Route.php';
require __DIR__ . '/../dclass/devups/Http/Router.php';

require __DIR__ . '/../dclass/devups/Interfaces/NotificationSerialize.php';

require __DIR__ . '/../dclass/dvups_functions.php';
require __DIR__ . '/../dclass/lib/lib_dependances.php';


require __DIR__ . '/../dclass/devups/Interfaces/WorkerCallback.php';
require __DIR__ . '/../dclass/extends/extends_dependances.php';
require __DIR__ . '/../dclass/generator/template/Templatedependences.php';

global $enittycollection;
global $em;
$em = DBAL::getEntityManager();

if (dbdumper) {
    $db_dump = new \dclass\devups\Tchutte\DB_dumper();
    $db_dump->dump();
}
