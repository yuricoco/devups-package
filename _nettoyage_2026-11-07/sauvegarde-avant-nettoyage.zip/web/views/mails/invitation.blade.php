@extends("mails.email")
@section("content")
    <div>
        <h1>Bonjour {{$invitation->name}},</h1>
        <p>{{$user->username}} vous invite en tanque <b>{{$member->role}}</b> Sur la BD {{$book->name}}
            sur la plateforme Events Afroskills</p>

        <p>
            Vous pourrez trouvez cette BD desormais dans votre compte creation : <a href="{{$url}}">Aller a mon compte</a>
        </p>

    </div>
@endsection