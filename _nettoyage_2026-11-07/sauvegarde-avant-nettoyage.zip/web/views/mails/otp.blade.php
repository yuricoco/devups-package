@extends("mails.email")
@section("content")

    <div style="color:#1f1f1f;line-height:1.25em;max-width:400px;margin:0 auto"
         align="center">
        <h3>
            {{langt("Aidez nous à proteger votre compte", "Help us protect your account", $lang)}}
        </h3>
        <p style="font-size:0.9em">
            {{langt("Avant que vous vous connectiez, nous avons besoin de verifier votre identite. Entrer le code suivant sur la page de verification",
"Before you sign in, we need to verify your identity. Enter the following
            code on the sign-in page.", $lang)}}

        </p>
        <div style="width:207px;height:53px;background-color:#f0f0f0;line-height:53px;font-weight:700;font-size:1.5em;color:#303030;margin:26px 0">
            {{$activation_code}}
        </div>
        <p style="font-size:0.75em">
            If you have not recently tried to sign into GitLab, we recommend <a
                    href="https://3ag-egitlab.com/account-settings/password/edit"
                    rel="noopener noreferrer"
                    style="color:#3777b0;text-decoration:none" target="_blank"
                   >changing
                your password</a> {{--and <a
                    href="https://gitlab.com/help/user/profile/account/two_factor_authentication.md"
                    rel="noopener noreferrer"
                    style="color:#3777b0;text-decoration:none" target="_blank"
                    >setting up Two-Factor Authentication</a> to keep your account safe. --}}
            {{langt("Votre code de verification expire dans 60 minutes",
"Your verification code expires after 60 minutes.", $lang)}}

        </p>
    </div>

@endsection