@extends("mails.email")
@section("content")

        <div style="max-width: 600px; margin: auto;   border-radius: 8px; padding: 30px; ">

            <h1 style="color: #000;">{{ langt("Bienvenue dans 3agReader 🎉", "Welcome to the 3agReader 🎉", $lang) }}</h1>

            <p>{{ langt("Salut", "Hi", $lang) }} {{ $user->username }} 👋,</p>

            <p>{{ langt("On est super heureux de t’avoir avec nous 🤩", "We're super happy to have you with us 🤩", $lang) }}</p>

            <p>{!! langt("Et pour bien commencer, voici <strong>300 Kolacoins </strong> offerts 🎁 !", "To get you started, here are 300 Kolacoins offered 🎁!", $lang)  !!}<br><br>
                {{ langt("Tu peux déjà les utiliser pour lire des chapitres ou choper du contenu dans la galerie.", "You can already use them to read chapters or grab content from the gallery.", $lang) }}</p>

            <p>{{ langt("Petit rappel de ce que tu peux faire ici :", "Quick reminder of what you can do here:", $lang) }}</p>

            <ul>
                <li>📚 {{ langt("Lire des BD et commenter, liker ou noter chaque chapitre", "Read comics and comment, like or rate each chapter", $lang) }}</li>
                <li>💬 {{ langt("Partager avec la communauté via des posts et des commentaires", "Share with the community via posts and comments (a bit like on Insta!)", $lang) }}</li>
                <li>🪙 {{ langt("Utiliser des Kolacoins pour débloquer du contenu digital", "Use Kolacoins to unlock digital content", $lang) }}</li>
                <li>🎨 {{ langt("Explorer la galerie : illustrations, fonds d’écran, emojis… de quoi te régaler", "Explore the gallery: illustrations, wallpapers, emojis... plenty to enjoy", $lang) }}</li>
            </ul>

            <p>{{ langt("Et ce n’est que le début !", "And that’s just the beginning!", $lang) }}</p>

            <h1>Espace createur</h1>
            <p>
                {{ langt(
        "Tu es dessinateur·rice, pense à t’enregistrer dans l’espace créateur ! Tu pourras :",
        "You're a comic artist, don't forget to register in the creator space! You’ll be able to:",
        $lang
    ) }}
            </p>

            <ul>
                <li>🎨 {{ langt("Partager tes illustrations, one-shots et séries", "Share your illustrations, one-shots and series", $lang) }}</li>
                <li>🌱 {{ langt("Faire grandir ta communauté", "Grow your community", $lang) }}</li>
                <li>💰 {{ langt("Vendre tes créations sur la plateforme", "Sell your creations on the platform", $lang) }}</li>
                <li>🤑 {{ langt("Gagner de l’argent avec ton art", "Earn money with your art", $lang) }}</li>
            </ul>

            <a href="https://creator.3ag-edition.com/" style="display: inline-block; margin-top: 15px; padding: 12px 20px; background-color: #1e88e5; color: #fff; text-decoration: none; border-radius: 6px; font-weight: bold;">
                {{ langt("Rejoindre l’espace créateur", "Join the creator space", $lang) }}
            </a>
            <hr>
            <p>{{ langt("Si t’as une question, une idée ou juste envie de dire coucou, on est là ✌️", "If you have a question, an idea or just want to say hi, we’re here ✌️", $lang) }}</p>

            <p>{{ langt("À très vite dans l’app 👀", "See you soon in the app 👀", $lang) }}</p>

            <p style="font-weight: bold;">— {{ langt("L’équipe 3ag", "The 3ag Team", $lang) }}</p>

        </div>


@endsection