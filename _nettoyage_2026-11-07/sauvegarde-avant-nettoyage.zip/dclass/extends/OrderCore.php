<?php


class OrderCore extends \Model implements JsonSerializable
{
    //use CurrencyTrait;
    /**
     * @Id @GeneratedValue @Column(type="integer")
     * @var int
     * */
    protected $id;
    /**
     * @Column(name="totalamount", type="float"  )
     * @var integer
     **/
    protected $totalamount = 0;
    /**
     * @Column(name="commission", type="float", nullable=true  )
     * @var integer
     **/
    protected $commission = 0;
    /**
     * @Column(name="discountprice", type="float"  )
     * @var integer
     **/
    protected $discountprice = 0;
    /**
     * @Column(name="nettopay", type="float"  )
     * @var integer
     **/
    protected $nettopay = 0;
    
    /**
     * @Column(name="kolacoin", type="float"  )
     * @var integer
     **/
    protected $kolacoin = 0;

    /**
     * @Column(name="status", type="integer" , nullable=true)
     * @var string
     **/
    protected $status;
    /**
     * @Column(name="due_date", type="date" , nullable=true )
     **/
    protected $due_date;

    /**
     * @ManyToOne(targetEntity="\User")
     * @JoinColumn(onDelete="Cascade")
     * @var \User
     */
    public $user;

    public function __construct($id = null)
    {

        $this->user = new User();
    }

}