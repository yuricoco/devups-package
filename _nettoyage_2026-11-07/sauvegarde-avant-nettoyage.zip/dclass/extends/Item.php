<?php


class Item extends \stdClass implements JsonSerializable
{

    use ModelTrait;

    /**
     * @Column(name="quantity", type="integer"  )
     * @var integer
     **/
    protected $quantity = 1;
    /**
     * @Column(name="price", type="integer"  )
     * @var integer
     **/
    protected $price;
    /**
     * @Column(name="totalprice", type="float", nullable=true  )
     * @var integer
     **/
    protected $totalprice;

    /**
     * @Column(name="attributes", type="json" , nullable=true )
     * @var string
     **/
    protected $attributes;
    /**
     * Accompagnement pour les produits qui sont dans une categorie qui necessite un accompagnement.
     *
     * @Column(name="description", type="string", length=125 , nullable=true )
     * @var string
     **/
    protected $description;
    /**
     * @Column(name="comment", type="text", nullable=true )
     * @var string
     **/
    protected $comment;

    /**
     * @Column(name="status", type="string", length=25, nullable=true  )
     * @var string
     **/
    protected $status;

    /**
     * @Column(name="discountprice", type="integer", nullable=true  )
     * @var integer
     **/
    protected $discountprice;

    /**
     * @Id @ManyToOne(targetEntity="\Product")
     * @JoinColumn(onDelete="cascade")
     * @var \Product
     */
    public $product;

    /**
     * @inheritDoc
     */
    public function jsonSerialize()
    {
        return [
            'quantity' => (float) $this->quantity,
            'price' => (float) $this->price,
            'status' => $this->status,
        ];
    }
}