<?php

use devupscms\ModulePushNotification\Entity\Workers;

class ScanCore extends \Model
{

    /**
     * @Id @GeneratedValue @Column(type="integer")
     * @var int
     * */
    protected $id;

    const right_to_left = 0;
    const left_to_right = 1;
    const top_to_bottom = 2;
    /**
     * @Column(name="readingdirection", type="integer"  )
     * @var boolean
     **/
    protected $readingdirection = self::left_to_right;
    /**
     * @Column(name="synopsis", type="text", nullable=true  )
     * @var text
     **/
    protected $synopsis;
    /**
     * @Column(name="available", type="integer", nullable=true  )
     * @var text
     **/
    public $available;

    /**
     * @Column(name="admin_status", type="integer", nullable=true  )
     * @var text
     **/
    public $admin_status = 1;
    /**
     * @Column(name="status", type="integer"  )
     * @var boolean
     **/
    protected $status = 0;
    /**
     * @ManyToOne(targetEntity="\Tree_item")
     * @JoinColumn(onDelete="set null")
     * @var \Tree_item
     */
    public $category;
    /**
     * @ManyToOne(targetEntity="\User")
     * @JoinColumn(onDelete="set null")
     * @var \User
     */
    public $user;
    /**
     * @ ManyToOne(targetEntity="\User")
     * @ JoinColumn(onDelete="set null")
     * @ var \User
     */
    // public $editor;
    /**
     * 800 x 1200
     * @Column(name="cover", type="string" , length=150 , nullable=true)
     * @var string
     **/
    protected $cover;

    /**
     * @Column(name="path", type="string" , length=120 , nullable=true)
     * @var string
     **/
    protected $path;

    /**
     * @Column(name="post_id", type="integer" , nullable=true )
     * @var boolean
     **/
    protected $post_id;
    /**
     * @Column(name="rate", type="float" , nullable=true )
     * @var boolean
     **/
    protected $rate;
    /**
     * @Column(name="nbvote", type="float" , nullable=true )
     * @var boolean
     **/
    protected $nbvote;
    /**
     * @Column(name="handle_stats_record", type="integer" , nullable=true )
     * @var boolean
     **/
    protected $handle_stats_record;

    /*
     * =======================================================================
     * VISIBILITE PUBLIQUE ET PUBLICATION PROGRAMMEE
     * =======================================================================
     *
     * La visibilite se CALCULE a la lecture, sans ordonnanceur :
     *
     *     public  <=>  status = 1 AND (published_at IS NULL OR published_at <= maintenant)
     *
     * `published_at IS NULL` = aucune programmation = comportement d'avant.
     * C'est ICI, et nulle part ailleurs, que vivent l'expression, le fuseau et la
     * regle « qui voit quoi » : les controleurs ne font qu'appeler ces methodes.
     * Elles sont dans `ScanCore` parce que c'est le parent commun de `Comicbook` et
     * `Chapter` ; `Illustration` (qui etend `ImageCore`) les appelle en statique.
     *
     * FUSEAU : `published_at` est un DATETIME NAIF dans l'horloge PHP du serveur,
     * la meme qui pose `created_at` (408 des 461 `chapter.published_at` existants
     * valent exactement `created_at`). On compare donc a `date()` de PHP, passe en
     * LITTERAL, JAMAIS a `NOW()` de MySQL (dont le fuseau est celui de la machine,
     * pas forcement celui de PHP). Si la production s'avere tourner dans un autre
     * fuseau que les auteurs (Douala, UTC+1, sans heure d'ete), c'est CETTE
     * constante qu'on regle : `null` = l'horloge du serveur.
     */
    const PUBLICATION_TIMEZONE = null;

    /** « Maintenant », au format de `published_at`, dans le fuseau de reference. */
    public static function publicationNow(): string
    {
        if (self::PUBLICATION_TIMEZONE === null) {
            return date('Y-m-d H:i:s');
        }
        return (new DateTime('now', new DateTimeZone(self::PUBLICATION_TIMEZONE)))->format('Y-m-d H:i:s');
    }

    /** La condition de DATE seule : aucune programmation, ou echeance passee. */
    public static function publishedSql(string $alias = 'this'): string
    {
        return "($alias.published_at IS NULL OR $alias.published_at <= '" . self::publicationNow() . "')";
    }

    /**
     * L'administration (session PHP `$_SESSION[ADMIN]`, jamais un JWT) ne voit
     * jamais de barriere : `Router::$admin_route` est vrai sur les deux seuls
     * points d'entree admin, comme pour `FrontController::assertOwnership()`.
     */
    private static function inAdminContext(): bool
    {
        return Router::$admin_route === true;
    }

    /**
     * Identifiant du lecteur, DERIVE DU JETON (`Auth::$user_id`, pose par
     * `Router::runServe()` apres verification de la signature), jamais d'un
     * parametre de requete : `account=creator`, que `Comicbook::lazyloading()`
     * lisait, est une affirmation du CLIENT et n'a aucune valeur.
     * 0 = anonyme.
     */
    private static function viewerId(): int
    {
        return (int)Auth::$user_id;
    }

    /**
     * SERIE publique, ou serie de l'auteur connecte (qui voit TOUT de la sienne,
     * brouillons et programmations comprises). Ni les abonnes ni l'equipe
     * (`member`) : aucune exception de plus.
     */
    public static function seriesVisibleSql(string $alias = 'this'): string
    {
        if (self::inAdminContext()) {
            return '1 = 1';
        }
        $public = "($alias.status = 1 AND " . self::publishedSql($alias) . ")";
        $uid = self::viewerId();
        return $uid ? "($public OR $alias.user_id = $uid)" : $public;
    }

    /**
     * CHAPITRE : proprietaire = `chapter.user_id` OU proprietaire de sa serie
     * (117 chapitres sur 494 ont un `user_id` nul : pour ceux-la, l'auteur est celui
     * de la serie).
     */
    private static function chapterOwnerSql(string $alias, int $uid): string
    {
        return "($alias.user_id = $uid OR $alias.comicbook_id IN (SELECT id FROM comicbook WHERE user_id = $uid))";
    }

    /**
     * La DATE de la serie d'un chapitre : tant que la serie est programmee, ses
     * chapitres ne sont pas publics, meme si eux-memes n'ont pas de date (sans
     * cela, programmer une serie la laisserait lisible par ses chapitres, et ils
     * apparaitraient dans le fil des derniers chapitres). La DATE seule, pas le
     * `status` de la serie : 12 chapitres publies appartiennent a des series
     * `status = 0` et restent lisibles, comme aujourd'hui. Un one-shot
     * (`comicbook_id` nul) n'a pas de serie.
     */
    private static function chapterSeriesDateSql(string $alias): string
    {
        return "($alias.comicbook_id IS NULL OR $alias.comicbook_id IN (SELECT id FROM comicbook WHERE "
            . self::publishedSql('comicbook') . "))";
    }

    /** CHAPITRE public, ou chapitre de l'auteur connecte (brouillons compris). */
    public static function chapterVisibleSql(string $alias = 'this'): string
    {
        if (self::inAdminContext()) {
            return '1 = 1';
        }
        $public = "($alias.status = 1 AND " . self::publishedSql($alias) . " AND " . self::chapterSeriesDateSql($alias) . ")";
        $uid = self::viewerId();
        return $uid ? "($public OR " . self::chapterOwnerSql($alias, $uid) . ")" : $public;
    }

    /**
     * Pour les LISTES qui imposent deja `status = 1` pour tout le monde
     * (`ChapterFrontController::index()`) : seule la date s'ajoute, et l'auteur
     * connecte voit ses chapitres programmes (c'est ce que montre son calendrier).
     * Ses brouillons (`status = 0`) restent hors de cette liste, comme avant.
     */
    public static function chapterScheduledOrOwnerSql(string $alias = 'this'): string
    {
        if (self::inAdminContext()) {
            return '1 = 1';
        }
        $uid = self::viewerId();
        $published = "(" . self::publishedSql($alias) . " AND " . self::chapterSeriesDateSql($alias) . ")";
        return $uid ? "($published OR " . self::chapterOwnerSql($alias, $uid) . ")" : $published;
    }

    /**
     * ILLUSTRATION : la barrière ne porte QUE sur la date. `illustration.status`
     * (« Public / Brouillon » dans le creator) n'est lu par personne : 51
     * illustrations sur 65 l'ont a 0 ou NULL et la v2 ne l'envoie pas. L'exiger
     * ferait disparaitre la galerie. L'auteur voit les siennes.
     */
    public static function illustrationVisibleSql(string $alias = 'this'): string
    {
        if (self::inAdminContext()) {
            return '1 = 1';
        }
        $published = self::publishedSql($alias);
        $uid = self::viewerId();
        return $uid ? "($published OR $alias.user_id = $uid)" : $published;
    }

    public function __construct($id = null)
    {

        if ($id) {
            $this->id = $id;
        }

        $this->category = new Tree_item();
        $this->user = new User();
        // $this->editor = new User();

    }

    public function getId()
    {
        return $this->id;
    }

    public function uploadCover($file = "cover")
    {

        $dfile = self::Dfile($file);


        dv_dump($dfile);
        if (!$dfile->errornofile) {
            if ($this->cover)
                Dfile::deleteFile($this->cover, $this->path);

            $filedir = $this->path;
            $url = $dfile
                ->hashname()
                //->saveoriginal(false)
                ->addresize([150, 150], "150_", "", true)
                ->addresize([270, 390], "270_", "", true)
                ->addresize([800], "", "", false)
                ->addresize([50, 50], "50_", "", true)
                ->moveto($filedir);

            if (!$url['success']) {
                return array(
                    'success' => false,
                    'error' => $url
                );
            }

            $this->cover = $url["file"]["hashname"];
            $this->__update([
                "this.cover" => $url["file"]["hashname"]
            ]);
        }
    }

    public function showImage($attribute, $prefix = "")
    {
        $url = Dfile::show($prefix . $this->{$attribute}, $this->path);
        return Dfile::fileadapter($url, $this->{$attribute});
    }

    public function srcImage($attribute, $prefix = "")
    {
        return Dfile::show($prefix . $this->{$attribute}, $this->path);
    }

    public function handleRateRecord()
    {
        if ($this->handle_stats_record == 0) {
            $this->__update(['handle_stats_record' => 1]);

            Workers::create([
                "type" => "scancore",
                "queue" => serialize($this),
                "payload" => '',
                //                "timer" => 5,
            ]);
        }
    }
}
