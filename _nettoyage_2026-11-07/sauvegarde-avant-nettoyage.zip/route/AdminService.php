<?php

namespace route;
use AdminTemplateGenerator;
use dclass\devups\Controller\FrontController;
use Dvups_entityController;
use Genesis;
use Notificationtype;
use Request;
use Genesis as g;
use OpenApi\Annotations as OA;

/**
 * @OA\Info(
 *   title="Devups API",
 *   version="1.0.0",
 *   description="Documentation des WebServices de Devups."
 * )
 *
 * @OA\Server(
 *   url="https://monsite.com/api",
 *   description="Serveur principal"
 * )
 */
class AdminService extends \dclass\devups\Controller\ModuleController
{

    /*
     * PoC
     * can it be possible to set an instance of the front controller then while instanciate it, making control of restrication,
     * either public access of global auth restrictions.
     */
    private $frontController;
    public function __construct($route)
    {
        // [adminauth-1] 2026-10-14 - SEUL point de passage de startAdmin()
        // vers manageServe() (dclass/devups/Http/Router.php:124-132, lu en
        // lecture seule) : `new AdminService('hello')` est construit AVANT
        // que manageServe() ne fasse quoi que ce soit. La verification de
        // session que manageServe() est censee faire est elle-meme du code
        // mort (son corps est commente) - sans ce garde-fou, systemServe(),
        // les methodes `…Service()` et Controller::serve() servaient TOUTES
        // les entites de config/dvups_configurations.php (171 entrees,
        // payout/payment/donate/orders comprises) SANS AUCUNE
        // authentification, ni jeton JWT ni session admin : demontre en
        // ecriture reelle sur des lignes jetables, voir
        // aiMemory/memory_2026-10-20_v1.md §1. assertOwnership() etait en
        // plus neutralisee par Router::$admin_route (pose avant ce
        // constructeur), donc meme les six entites a controle de propriete
        // etaient ouvertes a la modification d'autrui.
        //
        // Aucune exemption : le formulaire de connexion de l'administration
        // (admin/login.php) poste vers
        // `admin/devups/ModuleAdmin/dvups-admin/connexion-action`, qui ne
        // contient PAS `/api/` et ne passe donc jamais par ici (il passe par
        // Router::manage(), qui exempte explicitement `connexion-action` -
        // voir Router.php:463). Un refus ici ne peut donc jamais bloquer la
        // connexion elle-meme.
        //
        // Meme piege que les deux fois precedentes (WebService.php,
        // [commerce-7]) : sans `die`, un refus encode en JSON laisserait
        // l'execution continuer vers systemServe()/Controller::serve().
        if (!isset($_SESSION[ADMIN])) {
            http_response_code(401);
            Genesis::json_encode([
                'success' => false,
                'detail' => 'admin session required',
            ]);
            die;
        }

        parent::__construct($route);
        $this->frontController = new FrontController();
    }

    /**
     * @MethodView(GET="hello", Auth=1)
     */
    public function helloService()
    {
        Genesis::json_encode(["success" => true, "message" => "hello devups you made your first apicall"]);
    }

    public function systemServe()
    {

        FrontController::$entityname= self::$class_name;
        FrontController::$classMagic= self::$class_name;
        try {

            switch (self::$path) {
                case 'create':
                    g::json_encode($this->frontController->createCore());
                    break;
                case 'upload':
                    g::json_encode($this->frontController->uploadCore(Request::get("id")));
                    break;
                case 'update':
                    g::json_encode($this->frontController->updateCore(Request::get("id")));
                    break;
                case 'delete':
                    g::json_encode($this->frontController->deleteCore(Request::get("id")));
                    break;
                case 'detail':
                    g::json_encode($this->frontController->detailCore(Request::get("id")));
                    break;
                case 'lazyloading':
                    g::json_encode($this->frontController->ll());
                    break;
                case 'dcollection':
                    g::json_encode($this->frontController->dcollection());
                    break;

                default :
                    g::json_encode(["success" => false, "message" => "404 :" . Request::get('path') . " page note found"]);
                    break;
            }

        } catch (\Exception $e) {
            g::json_encode([
                'success' => false,
                'detail' => $e->getMessage(),
            ]);
        }
    }

    public function clonerowService()
    {
        $classname = ucfirst(Request::get("dclass"));
        //$entity = new $classname;
        //$result = $entity->__dclone( ); //,
        $entity = $classname::find(Request::get("id"));
        $entity->id = null; //,
        $result = $entity->__insert(); //,
        $message = $classname . ": Cloned with success";
//            Genesis::json_encode([
//                "message"=>$message
//            ]);
        Genesis::json_encode(compact("message", "entity", "result"));
    }

    public function exportService()
    {
        $classname = ucfirst(Request::get("classname"));
        $entity = new $classname;
        $result = $entity->exportCsv($classname); //,
        $message = $classname . ": CSV generated with success";
//            Genesis::json_encode([
//                "message"=>$message
//            ]);
        Genesis::json_encode(compact("message", "entity", "result"));
    }

    public function importService()
    {
        $classname = ucfirst(Request::get("classname"));
        $entity = new $classname;
        $response = $entity->importCsv($classname); //,
        $message = $classname . ": Core generated with success";
        Genesis::json_encode(compact("response", "message"));
    }

    public function export()
    {
        (new Dvups_entityController())->exportCsv();
    }

    /**
     * @MethodView(path="dvups-admin/complete-registration")
     */
    public function completeRegistrationView($id)
    {
        \devups\ModuleAdmin\ModuleAdmin::renderView('admin.dvups_admin.complete_registration', (new \Dvups_adminController())->completeRegistration($id));
    }

    public function connexionView($id)
    {
        \devups\ModuleAdmin\ModuleAdmin::renderView('admin.dvups_admin.complete_registration', (new \Dvups_adminController())->completeRegistration($id));
    }

    public function generateConstantesService($entity_name)
    {
        $classname = ucfirst($entity_name);
        $rows = [];
        if ($entity_name == 'notification'){

            Notificationtype::select()->cursor(function (Notificationtype $item) use (&$rows){
                $rows[] = " const {$item->dvups_entity->name}_{$item->_key} = \"{$item->_key}\"; ";
            });

        }
        elseif ($entity_name == 'status'){

            \Status::select()->cursor(function (\Status $item) use (&$rows){
                $rows[] = " const {$item->entity->name}_{$item->_key} = \"{$item->_key}\"; ";
            });

        }
        elseif ($entity_name == 'role'){

            \Dvups_role::select()->cursor(function (\Dvups_role $item) use (&$rows){
                $rows[] = " const {$item->name} = \"{$item->name}\"; ";
            });

        }
        elseif ($entity_name == 'tree_item'){
            $tree = \Tree::find(Request::get('treename'));
            $treename = (Request::get('treename'));
            $classname = "Tree".ucfirst($treename);
            \Tree_item::mainmenu($treename)->cursor(function (\Tree_item $item) use (&$rows, $treename){
                $rows[] = " const {$item->slug} = \"{$item->slug}\"; ";
            });

        }

        if (!$rows)
            Genesis::json_encode( [
                "success" => false,
                "detail" => "",
            ]);

        $content = "<?php
            class {$classname}Const {
                ".implode("\n", $rows)."
            }
        ";
        \DClass\lib\Util::writein($content, $classname.'Const.php', 'cache/constants/', 'w');

        if (!file_exists(ROOT.'cache/constants/'))
            Genesis::json_encode( [
                "success" => false,
                "detail" => "",
            ]);

        if (file_exists(ROOT.'cache/constants/require_constants.php'))
            unlink(ROOT.'cache/constants/require_constants.php');

        $files = scandir(ROOT.'cache/constants/');
        unset($files[0]);
        unset($files[1]);

        $requires = "<?php\n ";
        foreach ($files as $file)
            $requires .= "require __DIR__ . '/$file';\n";

        \DClass\lib\Util::writein($requires, 'require_constants.php', 'cache/constants/', 'w');

        Genesis::json_encode([
            "success" => true,
            "detail" => "Constants generated with success",
        ]);

    }

    public function web($path = "")
    {
        // TODO: Implement web() method.
    }

    public function services($path = "")
    {
        // TODO: Implement services() method.
    }

    public function webservices($path = "")
    {
        // TODO: Implement webservices() method.
    }
}