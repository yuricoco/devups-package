<?php

namespace route;

use Auth;
use Exception;
use Genesis as g;
use Request;
use Router; 
use devupsfront\ModuleUser\Entity\Oauth_client; 
use Google\Client; 
use Push_emailController; 

class WebService extends Router
{

    /*
     * Collection des entites joignables en HTTP.
     *
     */
    public $public_access =
    [ 
        'push_subscription' => \Push_subscription::class,  
        'notification' => \Notification::class,  
        'user' => \User::class,
    ];

    /**
     * Carte EXPLICITE et courte des seules methodes autorisees SANS jeton,
     * par entite. Toute entite de $public_access non listee ici devient
     * protegee sur TOUTES ses methodes (les cinq actions generiques ET ses
     * actions metier) : c'est la liste elle-meme qui doit rester courte et
     * relisible, pas une exception a documenter en prose ailleurs.
     *
     * Un nom de methode liste ici est le nom RESOLU par le routeur, celui que
     * Request.php:422 compare a cette liste : `index` pour GET /api/<entite>
     * (route de collection), `detail` pour GET /api/<entite>/<id>, et le nom
     * de l'action metier pour une route annotee (@GET(path='/ranking') ->
     * 'ranking').
     *
     * PRINCIPE DE CONSTRUCTION (2026-10-01) : la lecture anonyme est le coeur
     * du produit (on lit avant de s'inscrire), et le client mobile n'envoie le
     * jeton QUE s'il en a un - appv2/src/shared/api/client.ts:155-162 :
     *     if (!skipAuth) { const token = await getToken();
     *                      if (token) headers['Authorization'] = ...  }
     * avec un commentaire explicite sur la lecture et la decouverte anonymes
     * (client.ts:196-203). Toute lecture qu'un visiteur non connecte peut
     * atteindre doit donc figurer ici, sinon elle tombe en 401. Inversement,
     * rien de ce qui touche au compte, a l'ecriture ou a l'argent n'y figure.
     *
     * Etablie par recensement croise de TOUS les chemins d'API reellement
     * appeles par appv2/src/ et appreact/src/, confrontes aux methodes
     * reellement declarees dans chaque FrontController. Les actions laissees
     * protegees ne sont pas des oublis : elles sont nommees en commentaire
     * sous chaque entite. Detail du recensement et methode :
     * aiMemory/memory_2026-10-01_v1.md.
     */
    public static $publicMethods = [ 
        'user' => [
            'creators',
            'registration',
            'authentification',
            'tokenize',
            'activateaccount',
            'resentactivationcode',
            'initresetpassword',
            'resetpassword',
            'googleAuth',
            'appleAuth',
            'content',
            'detail',
        ],
    ];

    /**
     * Entites d'ARGENT dont le chemin GENERIQUE
     * (/api/{create|upload|update|delete|detail|lazyloading}/<entite>, servi
     * ci-dessous par systemServe()) ne doit RIEN exposer — lectures comprises.
     *
     * Ce chemin contourne entierement les FrontController dedies (Payout,
     * Payment, Donate, Orders) et leurs controles de propriete poses sur la
     * branche fix/commerce-auth ([commerce-1] a [commerce-4]) :
     * FrontController::authorization() (dclass/, lu en lecture seule ici)
     * exige bien un jeton pour ces quatre entites ($publicMethods ne les
     * exempte d'aucune methode, voir 'payment'/'donate' ci-dessus),
     * mais ni elle ni assertOwnership() ne verifient a QUI appartient la
     * ligne $id - assertOwnership() s'arrete aux six entites de
     * FrontController::$ownerColumn (comicbook, chapter, post, postcomment,
     * illustration, follow), qui ne couvrent pas le commerce.
     *
     * Demontre en ecriture reelle contre le backend local (comptes jetables,
     * aucune ligne reelle touchee) : un jeton valide de N'IMPORTE QUEL
     * utilisateur suffisait a lire les coordonnees (telephone, e-mail, nom)
     * d'une demande de retrait d'autrui, modifier son `amount`/`status`, la
     * supprimer, creer un retrait ou un don AU NOM d'un autre (`user.id` du
     * corps), et lister les dons/retraits de tout le monde — y compris via
     * `<entite>_bulk`, qui insere plusieurs lignes d'un coup. Voir
     * aiMemory/memory_2026-10-17_v1.md §1 pour le detail avant/apres.
     *
     * Aucun des quatre clients (appv2/, appreact/, creator/, website/)
     * n'appelle ce chemin pour l'une de ces quatre entites, lecture ou
     * ecriture (meme rapport, §2, recensement exhaustif par grep) : le
     * fermer entierement ne casse rien de constate.
     *
     * Volontairement PAS dans dclass/ (ou irait le reflexe naturel,
     * FrontController::$ownerColumn) : dclass/devups/Controller/
     * FrontController.php est modifie par hotfix/auth-security, dont
     * l'historique est independant de v3 — y ecrire une ligne serait une
     * ligne a refusionner a la main le jour de son deploiement.
     * route/WebService.php n'est pas touche par ce hotfix, et c'est deja le
     * fichier qui declare ce que ce chemin expose ($public_access,
     * $publicMethods ci-dessus) : le garde-fou est donc ici, a cote des deux
     * autres listes, pas enfoui dans une condition.
     */
    private static $genericPathMoneyEntities = [ ];

    /**
     * `product` est un cas different de celui ci-dessus : son CATALOGUE est
     * public par construction (ProductFrontController::index/catalog/
     * categories/detail, $publicMethods['product'] ci-dessus) et CE chemin
     * generique en lecture n'a pas ete audite dans toutes ses formes
     * d'appel — bloquer `detail`/`lazyloading` ici sans verification
     * pourrait casser un appel reel non recense. Seules ses ECRITURES
     * generiques sont donc fermees (create/upload/update/delete), en echo du
     * controle deja pose dans ProductFrontController::create()/update()/
     * delete() (fix/commerce-auth, [commerce-5]) : l'administration du
     * catalogue n'a aucune existence cote jeton JWT (Dvups_admin n'a aucun
     * lien avec User), donc une ecriture generique sur ce chemin est
     * refusee a tout appelant de l'API, comme son equivalent REST.
     */
    /**
     * [stickers-3] `sticker` ajoute a cote de `product`, meme raison : son
     * catalogue EST lu par ce chemin (une fois le jeton exige - `sticker`
     * n'a aucune methode publique, voir plus haut), mais ses ECRITURES
     * generiques contourneraient `denyUnlessAdmin()` (validate/reject) et la
     * propriete forcee depuis la session (propose) - exactement le risque
     * documente pour `product` ci-dessus.
     */
    private static $genericPathWriteBlockedEntities = [ ];

    /** Actions d'ECRITURE du chemin generique ; 'detail'/'lazyloading' restent des lectures. */
    private static $genericPathWriteActions = ['create', 'upload', 'update', 'delete'];

    public $append_routes = [];

    /*
     * PoC
     * can it be possible to set an instance of the front controller then while
     * instanciate it, making control of restrication, either public access of
     * global auth restrictions.
     */
    private $frontController;

    public function __construct($route)
    {

        // Protection par defaut. Exposer une entite dans $public_access la
        // protege du meme geste : toute entite listee devient restreinte sur
        // toutes ses methodes, sauf celles nommees dans $publicMethods
        // ci-dessus. Avant, une entite non explicitement restreinte a la main
        // (Auth::addRestriction()) restait ouverte sur toutes ses methodes,
        // generiques ET personnalisees, sans jeton. Tenir cette liste a la
        // main derive necessairement quand des entites s'ajoutent : c'est ce
        // qui a produit le trou corrige par [sec2-1] dans backend/ (16
        // entites sur 20 ouvertes au CRUD anonyme, voir
        // aiMemory/memory_2026-09-29_v1.md).
        foreach (array_keys($this->public_access) as $entity) {
            Auth::addRestriction($entity, self::$publicMethods[$entity] ?? []);
        }
        $this->frontController = new \dclass\devups\Controller\FrontController();

        parent::__construct($route);
    }

    /*
     * the service method should always follow the nomenclatura nameserviceServe
     * adding the suffix Serve to the name of the method allow the method to be accessible via webservice.
     */
    /**
     * @OA\Get(
     *     path="/hello",
     *     summary="Récupère la liste des livres",
     *     tags={"Books"},
     *     @OA\Response(
     *         response=200,
     *         description="Liste des livres",
     *         @OA\JsonContent(type="array", @OA\Items(ref="#/components/schemas/Book"))
     *     )
     * )
     */
    public function helloServe()
    {
        g::json_encode(["success" => true, "message" => "hello devups you made your first apicall"]);
    }

    public function systemServe()
    {
        $classname = \dclass\devups\Controller\FrontController::getclassname($this->public_access);

        try {
            $this->frontController->authorization($classname, self::$path);
        } catch (Exception $e) {
            // Le `die` est indispensable : sans lui, l'echec d'autorisation
            // etait encode en JSON puis l'execution CONTINUAIT vers le
            // switch ci-dessous - createCore()/updateCore()/deleteCore()/
            // uploadCore() s'executaient donc malgre le refus. Verifie en
            // direct le 2026-10-01 : sur POST /api/create/comicbook sans
            // jeton, le refus etait bien emis mais la requete poursuivait sa
            // route (voir aiMemory/memory_2026-10-01_v1.md). Correctif de
            // meme nature que celui du commit 9862ebf ([sec2-1]) dans
            // backend/, archive.
            http_response_code(401);
            g::json_encode([
                'success' => false,
                'detail' => $e->getMessage()
            ]);
            die;
        }

        // Garde-fou du chemin generique pour les entites d'argent
        // ($genericPathMoneyEntities / $genericPathWriteBlockedEntities,
        // declarees plus haut a cote de $public_access/$publicMethods) :
        // authorization() ci-dessus exige deja un jeton pour ces entites,
        // mais aucune propriete - voir le commentaire de
        // $genericPathMoneyEntities pour la demonstration.
        //
        // Meme piege que le bloc precedent, memes consequences : sans `die`,
        // ce refus encode en JSON laisserait l'execution CONTINUER vers le
        // switch ci-dessous, qui executerait quand meme createCore()/
        // updateCore()/deleteCore()/detailCore()/ll().
        if (
            in_array($classname, self::$genericPathMoneyEntities, true)
            || (
                in_array($classname, self::$genericPathWriteBlockedEntities, true)
                && in_array(self::$path, self::$genericPathWriteActions, true)
            )
        ) {
            http_response_code(403);
            g::json_encode([
                'success' => false,
                // Ne dit pas si la ligne existe : ce chemin ne sert ni
                // lecture ni ecriture pour cette entite, quel que soit l'id.
                'detail' => 'this path does not serve this entity',
            ]);
            die;
        }

        try {

            switch (self::$path) {
                case 'create':
                    g::json_encode($this->frontController->createCore());
                    break;
                case 'upload':
                    g::json_encode($this->frontController->uploadCore(Request::get("id")));
                    break;
                case 'update':
                    g::json_encode($this->frontController->updateCore(Request::get("id")));
                    break;
                case 'delete':
                    g::json_encode($this->frontController->deleteCore(Request::get("id")));
                    break;
                case 'detail':
                    g::json_encode($this->frontController->detailCore(Request::get("id")));
                    break;
                case 'lazyloading':
                    g::json_encode($this->frontController->ll());
                    break;
                case 'dcollection':
                    g::json_encode($this->frontController->dcollection());
                    break;
                case 'dcronjob':
                    g::json_encode((new Push_emailController())->cronjobAction());
                    break;

                default:
                    g::json_encode(["success" => false, "message" => "404 :" . Request::get('path') . " page note found"]);
                    break;
            }
        } catch (\Exception $e) {
            g::json_encode([
                'success' => false,
                'detail' => $e->getMessage(),
            ]);
        }
    }
 
    public function cacheServe()
    { 
        $statues = [];
        g::json_encode([
            'success' => true, 
            '__cache_version' => __cache_version,
            'countries' => \Country::allrows(),
        ]  );
    }

 
}
