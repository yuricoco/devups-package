@extends('admin.layout')
@section('title', 'List')

@section('layout_content')

    <div id="detail-user" data-url="{{User::classpath("services.php?path=")}}" class="row">
        <div class="col-lg-4 col-md-12  stretch-card">
            <div class="card">
                <div class="card-header-tab card-header">
                    <div class="card-header-title">
                        <i class="header-icon lnr-rocket icon-gradient bg-tempting-azure"> </i>
                        {{$user->username}}
                    </div>
                    <div class="btn-actions-pane-right">
                        <div class="nav">

                        </div>
                    </div>
                </div>
                <div class="card-body">

                    <table class="table">
                        <tr>
                            <th>Solde #{{$user->wallet->id}}</th>
                            <td>:  {{$user->wallet->amount}}</td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td>:  {{$user->email}}</td>
                        </tr>
                        <tr>
                            <th>Tel</th>
                            <td>:  {{$user->phonenumber}}</td>
                        </tr>
                    </table>

                </div>

            </div>
        </div>

        <div class="col-lg-6 col-md-12  stretch-card">
            <h3>Test Push notifications</h3>
            {!! Push_subscriptionTable::init(new Push_subscription())
                ->Qb(function($query) use ($user){
                return $query->where('this.user_id', $user->id);
            })
            ->addFilterParam('dfilters', "on")
            ->addFilterParam('user.id:eq', $user->id)
            ->addFilterParam('tablemodel', 'dashboard')
            ->buildindextable()
            ->render()
                !!}
        </div>
    </div>
    <div class="row"> 
        <div class="col-4">
            <h3>
                @tt("ACHAT ")
            </h3>
            @if($user->wallet->id)
            {!! WallettransactionTable::init(new Wallettransaction())
                ->Qb(function($query) use ($user){
                return $query->where('this.wallet_id', $user->wallet->id);
            })
            ->addFilterParam('dfilters', "on")
            ->addFilterParam('wallet.id:eq', $user->wallet->id)
            ->addFilterParam('tablemodel', 'dashboard')
            ->buildindextable()
            ->render()
                !!}
            @endif
        </div>
        <div class="col-4">
            <h3>
                @tt("DONATION ")
            </h3>
            {!! DonateTable::init(new Donate())
                ->Qb(function($query) use ($user){
                return $query->where('this.user_id', $user->id);
            })
            ->addFilterParam('dfilters', "on")
            ->addFilterParam('user.id:eq', $user->id)
            ->addFilterParam('tablemodel', 'dashboard')
            ->buildindextable()
            ->render()
                !!}

        </div>
        <div class="col-4">
            <h3>
                @tt("REVENU ")
            </h3>
            {!! TransactionTable::init(new Transaction())
                ->Qb(function($query) use ($user){
                return $query->where('this.user_id', $user->id);
            })
            ->addFilterParam('dfilters', "on")
            ->addFilterParam('user.id:eq', $user->id)
            ->addFilterParam('tablemodel', 'dashboard')
            ->buildindextable()
            ->render()
                !!}

        </div>
        <div class="col-4">
            <h3>
                @tt("FOLLOWING ")
            </h3>
            <p>Nombre de personnes que cet utilisateur suit</p>
            {!! UserTable::initRelation(new Follow())
                ->Qb(function($query) use ($user){
                return $query->where('this.follower_id', $user->id);
            })
            ->addFilterParam('dfilters', "on")
            ->addFilterParam('user.id:eq', $user->id)
            ->addFilterParam('tablemodel', 'relation')
            ->buildrelationtable()
            ->render()
                !!}

        </div>
        <div class="col-4">
            <h3>
                @tt("FOLLOWERS ")
            </h3>
            <p>Nombre de personnes qui suivent cet utilisateur</p>
            {!! UserTable::initRelation(new Follow())
                ->Qb(function($query) use ($user){
                return $query->where('this.following_id', $user->id);
            })
            ->addFilterParam('dfilters', "on")
            ->addFilterParam('user.id:eq', $user->id)
            ->addFilterParam('tablemodel', 'relation')
            ->buildrelationtable()
            ->render()
                !!}

        </div>
        <div class="col-12">
            <h3>
                @tt("RECHARGE PAYMENTS")
            </h3>
            <p>List of payments made by the current user for its own purpose</p>
            {!! PaymentTable::init(new Payment())
            ->Qb(function($query) use ($user){
                return $query->where('this.user_id', $user->id);
            })
            ->addFilterParam('dfilters', "on")
            ->addFilterParam('user.id:eq', $user->id)
            ->addFilterParam('tablemodel', 'dashboard')
            ->buildindextable()
            ->render()
                !!}

        </div>
        <div class="col-lg-12 col-md-12  stretch-card">
            <h3>Lectures</h3>
            {!! ChapterTable::initUser(new Chapter_user())
                ->builduserTable($user->id)
                ->addFilterParam('user_id', $user->id)
                ->setModel('user')
                ->render() !!}

        </div>
    </div>

@endsection

@section("jsimport")
    <script>
        model.sendmail = function (el, idnotif, iduser) {
            model.addLoader($(el))
            Drequest.init(__env + "admin/api/user.sendnotification?idnotif=" + idnotif + "&userid=" + iduser)
                .get((response) => {
                    model.removeLoader()
                    alert("Relance envoyer avec succes")
                    console.log(response)
                })
        }
    </script>
@endsection