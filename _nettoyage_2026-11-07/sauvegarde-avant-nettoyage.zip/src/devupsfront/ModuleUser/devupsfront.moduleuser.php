<?php

 
    require 'Entity/User.php';
    require 'Form/UserForm.php';
    require 'Datatable/UserTable.php';
    require 'Controller/UserController.php'; 
    
require 'Entity/Oauth_client.php';
require 'Datatable/Oauth_clientTable.php';
require 'Controller/Oauth_clientController.php';

