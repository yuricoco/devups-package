<?php


use dclass\devups\Datatable\Datatable as Datatable;

class UserTable extends Datatable
{


    public function __construct($user = null, $datatablemodel = [])
    {
        parent::__construct($user, $datatablemodel);
    }

    public static function init(\User $user = null)
    {

        $dt = new UserTable($user);
        $dt->entity = $user;

        return $dt;
    }

    public function buildindextable()
    {

        $this->base_url = __env . "admin/";
        $this->order_by = " this.id desc ";
        $this->qbcustom->addColumn(" select count(*) from chapter_user where user_id = this.id ", 'nb_read')
            ->with('country', ['name']);
        $this->datatablemodel = [
            'id' => ['header' => t('#'),],
            'src_profile' => ['header' => t('Profile'), 'value' => 'src:profile'],
            //            'firstname' => ['header' => t('Firstname'),],
            'is_activated' => ['header' => t('Activated'),],
            'username' => ['header' => t('Username'),],
            'email' => ['header' => t('Email'),],
            'country.name' => ['header' => t('Pays'),],
            'phonenumber' => ['header' => t('Phonenumber'),],
            //'lang' => ['header' => t('Lang'),],
            'created_at' => ['header' => t('Cree le'),],
            'updated_at' => ['header' => t('Last Update'), 'order' => true],
            'nb_read' => ['header' => t('Read'),],
            'wallet.amount' => ['header' => t('Balance'), 'order' => true],
        ];

        if (Request::get('filter') == 'creator') {
            $this->qbcustom->addColumns("(select count(*) from comicbook where user_id = this.id) as nb_comicbooks")
                ->addColumns("(select count(*) from chapter where comicbook_id is null and user_id = this.id) as nb_oneshots")
                ->addColumns("(select count(*) from comicbook where user_id = this.id) + (select count(*) from chapter where comicbook_id is null and user_id = this.id) as nb_creations")
                ->where_str("(
                (select count(*) from comicbook where user_id = this.id) +
                (select count(*) from chapter where comicbook_id is null and user_id = this.id)
            ) > 0");
            $this->datatablemodel['nb_creations'] = ['header' => t('Creations'), 'order' => true];
            $this->addFilterParam('filter', 'creator');
        }

        $this->addcustomaction(function ($item) {
            return \dclass\devups\model\Dbutton::link(
                'Detail',
                User::classview('user/detail?id=' . $item->id),
                'btn btn-info'
            )
                ->render();
        });

        return $this;
    }
    public function builddashboardtable()
    {

        $this->enabletopaction = false;
        $this->groupaction = false;
        $this->enablefilter(false);
        $this->base_url = __env . "admin/";
        $this->order_by = " nb_completed desc ";
        $this->qbcustom->addColumn(" select count(*) from chapter_user where user_id = this.id ", 'nb_read');
        $this->qbcustom->addColumn(" select count(*) from chapter_user where user_id = this.id and completed = 1 ", 'nb_completed');
        $this->datatablemodel = [
            'id' => ['header' => t('#'),],
            'username' => ['header' => t('Username'),],
            'nb_completed' => ['header' => t('Complete'), 'order' => true,],
            'nb_read' => ['header' => t('Read'), 'order' => true,],
        ];

        $this->disableDefaultaction();
        $this->actionDropdown = false;
        $this->addcustomaction(function ($item) {
            return \dclass\devups\model\Dbutton::link(
                'Detail',
                User::classview('user/detail?id=' . $item->id),
                'btn btn-info'
            )
                ->render();
        });

        return $this;
    }

    public static function initRelation($relation)
    {

        $dt = new UserTable($relation);
        $dt->entity = $relation;

        return $dt;
    }

    public function buildrelationtable()
    {

        $this->enabletopaction = false;
        $this->groupaction = false;
        $this->enablefilter(false);
        $this->base_url = __env . "admin/";
        $this->qbcustom
            ->with("follower", ['username'])
            ->with("following", ['username']);
        $this->datatablemodel = [
            'follower.username' => ['header' => t('Follower'),],
            'following.username' => ['header' => t('Following'),],
        ];

        $this->disableDefaultaction();
        $this->actionDropdown = false;
        // $this->addcustomaction(function ($item){
        //    return \dclass\devups\model\Dbutton::init('Detail',
        //        ('onclick=user/detail?id='.$item->id), 'btn btn-info')
        //        ->render();
        // });

        return $this;
    }

    public function builddetailtable()
    {
        $this->datatablemodel = [
            ['label' => t('firstname'), 'value' => 'firstname'],
            ['label' => t('lastname'), 'value' => 'lastname'],
            ['label' => t('email'), 'value' => 'email'],
            ['label' => t('sexe'), 'value' => 'sexe'],
            ['label' => t('phonenumber'), 'value' => 'phonenumber'],
            ['label' => t('password'), 'value' => 'password'],
            ['label' => t('resettingpassword'), 'value' => 'resettingpassword'],
            ['label' => t('is_activated'), 'value' => 'is_activated'],
            ['label' => t('activationcode'), 'value' => 'activationcode'],
            ['label' => t('birthdate'), 'value' => 'birthdate'],
            ['label' => t('creationdate'), 'value' => 'creationdate'],
            ['label' => t('lang'), 'value' => 'lang'],
            ['label' => t('username'), 'value' => 'username'],
            ['label' => t('has_shop'), 'value' => 'has_shop']
        ];
        // TODO: overwrite datatable attribute for this view
        return $this;
    }

    public function router()
    {
        $tablemodel = Request::get("tablemodel", null);
        if ($tablemodel && method_exists($this, "build" . $tablemodel . "table") && $result = call_user_func(array($this, "build" . $tablemodel . "table"))) {
            return $result;
        } else
            switch ($tablemodel) {
                // case "": return this->
                default:
                    return $this->buildindextable();
            }
    }
}
