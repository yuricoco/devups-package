<?php

/**
 * Génère le JSON OpenAPI 3.0 pour l'API 3ag Reader.
 *
 * Stratégie : parsing statique des annotations Devups (@Api, @GET, @POST…)
 * dans les FrontControllers, sans charger les classes PHP.
 * - Les entités dotées d'un FrontController sont documentées en style REST.
 * - Les entités SANS FrontController reçoivent les routes legacy CRUD.
 * - Seules les entités présentes dans WebService::$public_access sont incluses.
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// ─── Helpers ──────────────────────────────────────────────────────────────────

function parseDevupsDoc(string $doc): array
{
    $r = ['method' => null, 'subpath' => null, 'auth' => false, 'summary' => '', 'api' => null, 'apiDescription' => null];

    if (preg_match('/@(GET|POST|PUT|DELETE)(?:\s*\(([^)]*)\))?/i', $doc, $m)) {
        $r['method'] = strtolower($m[1]);
        $attrs = $m[2] ?? '';
        if (preg_match('/path=[\'"]([^\'"]*)[\'"]/',        $attrs, $pm)) $r['subpath'] = $pm[1];
        if (preg_match('/description=[\'"]([^\'"]+)[\'"]/', $attrs, $dm)) $r['summary'] = $dm[1];
    }
    if (preg_match('/@Api\s*\(([^)]+)\)/i', $doc, $m)) {
        $attrs = $m[1];
        if (preg_match('/name=[\'"]([^\'"]+)[\'"]/i',        $attrs, $nm)) $r['api']            = $nm[1];
        if (preg_match('/description=[\'"]([^\'"]+)[\'"]/i', $attrs, $dm)) $r['apiDescription'] = $dm[1];
    }
    if (preg_match('/@Auth\s*\(\s*authorized\s*=\s*1\s*\)/i', $doc)) {
        $r['auth'] = true;
    }
    foreach (explode("\n", $doc) as $line) {
        $line = trim(ltrim($line, " \t/*"));
        if ($line !== '' && $line[0] !== '@') { $r['summary'] = $line; break; }
    }
    return $r;
}

function toOaPath(string $path): string
{
    return preg_replace('/\/:([a-zA-Z_][a-zA-Z0-9_]*)/', '/{$1}', $path);
}

function pathParams(string $path): array
{
    preg_match_all('/\{([a-zA-Z_][a-zA-Z0-9_]*)\}/', $path, $m);
    return array_map(fn($p) => ['name' => $p, 'in' => 'path', 'required' => true, 'schema' => ['type' => 'integer']], $m[1]);
}

function makeOp(string $tag, string $summary, bool $auth, array $pParams = [], array $qParams = []): array
{
    $op = [
        'tags'      => [$tag],
        'summary'   => $summary,
        'responses' => ['200' => ['description' => 'Succès'], '401' => ['description' => 'Non authentifié']],
    ];
    if ($auth) $op['security'] = [['BearerAuth' => []]];
    $params = array_merge($pParams, $qParams);
    if ($params) $op['parameters'] = $params;
    return $op;
}

function jsonBody(string $entity): array
{
    return ['required' => true, 'content' => ['application/json' => [
        'schema' => ['type' => 'object', 'properties' => [$entity => ['type' => 'object']]],
    ]]];
}

// ─── Lecture de WebService.php ────────────────────────────────────────────────

$wsFile    = __DIR__ . '/../route/WebService.php';
$wsContent = file_get_contents($wsFile);

preg_match('/\$public_access\s*=\s*\[(.*?)\];/s', $wsContent, $pam);
preg_match_all("/['\"](\w+)['\"]\s*=>/", $pam[1] ?? '', $pakm);
$publicKeys = $pakm[1] ?? [];

preg_match_all("/Auth::addRestriction\(['\"](\w+)['\"],\s*\[\]/", $wsContent, $arm);
$fullAuthEntities = $arm[1] ?? [];

// ─── Paramètres réutilisables ─────────────────────────────────────────────────

$dfilterParams = [
    ['name' => 'dfilters',  'in' => 'query', 'schema' => ['type' => 'string'],  'example' => 'on',  'description' => 'Activer les filtres (`dfilters=on&champ:eq=valeur`)'],
    ['name' => 'per_page',  'in' => 'query', 'schema' => ['type' => 'integer'], 'example' => 30,    'description' => 'Résultats par page (défaut 30)'],
    ['name' => 'next',      'in' => 'query', 'schema' => ['type' => 'integer'], 'example' => 1,     'description' => 'Numéro de page'],
    ['name' => 'dsort',     'in' => 'query', 'schema' => ['type' => 'string'],  'description' => 'Champ de tri'],
    ['name' => 'direction', 'in' => 'query', 'schema' => ['type' => 'string'],  'enum' => ['ASC', 'DESC']],
];
$idQueryParam = ['name' => 'id', 'in' => 'query', 'required' => true, 'schema' => ['type' => 'integer']];

// ─── Spec OpenAPI ─────────────────────────────────────────────────────────────

$spec = [
    'openapi' => '3.0.0',
    'info'    => [
        'title'       => '3ag Reader – API',
        'version'     => '1.0.0',
        'description' =>
            "API REST de la plateforme **3ag Reader**.\n\n"
            . "## Styles de routes\n\n"
            . "### Style REST (`/{entité}`, `/{entité}/{id}`)\n"
            . "Entités dotées d'un **FrontController dédié** — verbes HTTP stricts. "
            . "C'est le style principal utilisé par l'application mobile.\n\n"
            . "### Style Legacy (`/action/{entité}`) — entités sans FrontController\n"
            . "Routes génériques : `/create/{e}`, `/detail/{e}?id=X`, `/update/{e}?id=X`, "
            . "`/delete/{e}?id=X`, `/lazyloading/{e}`\n\n"
            . "**Filtres dynamiques** : `?dfilters=on&champ:op=valeur`  \n"
            . "Opérateurs : `eq neq gt lt get let lk in notin isNull notNull btw`  \n"
            . "Pagination : `?next=<page>&per_page=<n>` — inspecter `remain` dans la réponse.\n\n"
            . "## Authentification\n"
            . "`Authorization: Bearer <jwt>`",
    ],
    'servers'    => [['url' => '/api', 'description' => 'http://127.0.0.1:3333/api']],
    'components' => ['securitySchemes' => ['BearerAuth' => ['type' => 'http', 'scheme' => 'bearer', 'bearerFormat' => 'JWT']]],
    'tags'       => [],
    'paths'      => [],
];

$paths           = [];
$tags            = [];
$entitiesWithFC  = []; // clés ayant un FrontController REST

// ═══════════════════════════════════════════════════════════════════════════════
// PASSE 1 — Routes REST (FrontControllers)
// ═══════════════════════════════════════════════════════════════════════════════

$fcFiles = glob(__DIR__ . '/../src/*/*/Controller/*FrontController.php');
sort($fcFiles);

foreach ($fcFiles as $fcFile) {
    $content = file_get_contents($fcFile);

    if (!preg_match('/class\s+(\w+FrontController)/i', $content, $cm)) continue;
    $fcName = $cm[1];

    preg_match('/\/\*\*(.*?)\*\/\s*class\s+' . preg_quote($fcName, '/') . '/s', $content, $cdm);
    $classAnnot = parseDevupsDoc($cdm[0] ?? '');
    $basePath   = $classAnnot['api'];
    if (!$basePath) continue;

    $entityKey = ltrim($basePath, '/');
    if (!in_array($entityKey, $publicKeys)) continue;

    $entitiesWithFC[] = $entityKey;   // ← marquer comme "a un FrontController"

    $fullAuth = in_array($entityKey, $fullAuthEntities);
    $tag      = "REST – $entityKey";
    $apiDesc  = $classAnnot['apiDescription'] ?? null;
    $tags[]   = ['name' => $tag, 'description' => $apiDesc ?: "Routes REST `$basePath` — `$fcName`"];

    preg_match_all(
        '/\/\*\*(.*?)\*\/\s*public\s+function\s+(\w+)\s*\(([^)]*)\)/s',
        $content, $mmatches, PREG_SET_ORDER
    );

    foreach ($mmatches as $mm) {
        $annot = parseDevupsDoc('/**' . $mm[1] . '*/');
        if ($annot['method'] === null) continue;

        $fullPath = toOaPath($basePath . $annot['subpath']);
        $pParams  = pathParams($fullPath);
        $summary  = $annot['summary'] ?: ucfirst($mm[2]) . ' ' . $entityKey;
        $auth     = $annot['auth'] || $fullAuth;
        $verb     = $annot['method'];

        $op = makeOp($tag, $summary, $auth, $pParams);
        if (in_array($verb, ['post', 'put'])) $op['requestBody'] = jsonBody($entityKey);
        if ($mm[2] === 'index' && $verb === 'get') {
            $op['parameters'] = array_merge($op['parameters'] ?? [], $dfilterParams);
        }

        $paths[$fullPath][$verb] = $op;
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// PASSE 2 — Routes Legacy CRUD (uniquement pour entités SANS FrontController)
// ═══════════════════════════════════════════════════════════════════════════════

$legacyEntities = array_diff($publicKeys, $entitiesWithFC);

if ($legacyEntities) {
    $tags[] = [
        'name'        => 'Legacy CRUD',
        'description' => 'Routes génériques `/action/{entité}` — entités sans FrontController dédié.',
    ];
}

foreach ($legacyEntities as $ek) {
    $tag      = "Legacy – $ek";
    $fullAuth = in_array($ek, $fullAuthEntities);
    $tags[]   = ['name' => $tag, 'description' => "Routes legacy pour `$ek`"];

    $paths["/lazyloading/$ek"]['get'] = makeOp($tag, "Lister $ek (paginé)", $fullAuth, [], $dfilterParams);
    $paths["/detail/$ek"]['get']      = makeOp($tag, "Détail d'un $ek",     $fullAuth, [], [$idQueryParam]);

    $op = makeOp($tag, "Créer un $ek", true);
    $op['requestBody'] = jsonBody($ek);
    $paths["/create/$ek"]['post'] = $op;

    $op = makeOp($tag, "Modifier un $ek", true, [], [$idQueryParam]);
    $op['requestBody'] = jsonBody($ek);
    $paths["/update/$ek"]['post'] = $op;

    $paths["/delete/$ek"]['get'] = makeOp($tag, "Supprimer un $ek", true, [], [$idQueryParam]);
}

// ═══════════════════════════════════════════════════════════════════════════════
// PASSE 3 — Services spéciaux WebService::*Serve()
// ═══════════════════════════════════════════════════════════════════════════════

$tags[] = ['name' => 'Services', 'description' => 'Routes de service — méthodes `*Serve()` de `WebService`'];

preg_match_all(
    '/\/\*\*(.*?)\*\/\s*public\s+function\s+(\w+Serve)\s*\(/s',
    $wsContent, $smatches, PREG_SET_ORDER
);
foreach ($smatches as $sm) {
    $routeKey = preg_replace('/Serve$/', '', $sm[2]);
    if ($routeKey === 'system') continue;
    $annot = parseDevupsDoc('/**' . $sm[1] . '*/');
    $paths["/$routeKey"]['get'] = makeOp('Services', $annot['summary'] ?: ucfirst($routeKey), false);
}

// ═══════════════════════════════════════════════════════════════════════════════
// PASSE 4 — Routes explicites (Auth sociale)
// ═══════════════════════════════════════════════════════════════════════════════

$tags[] = ['name' => 'Auth', 'description' => 'Authentification sociale (Google, Apple)'];

$paths['/user/googleAuth']['post'] = [
    'tags'        => ['Auth'],
    'summary'     => 'Connexion / inscription via Google OAuth',
    'requestBody' => ['required' => true, 'content' => ['application/json' => ['schema' => [
        'type' => 'object', 'required' => ['idToken'],
        'properties' => ['idToken' => ['type' => 'string', 'description' => 'ID Token Google Sign-In']],
    ]]]],
    'responses' => [
        '200' => ['description' => 'JWT + user + `isNewAccount`', 'content' => ['application/json' => ['schema' => [
            'type' => 'object',
            'properties' => [
                'success'      => ['type' => 'boolean'],
                'jwt'          => ['type' => 'string'],
                'user'         => ['type' => 'object'],
                'isNewAccount' => ['type' => 'boolean', 'description' => 'true si compte créé à cet appel'],
            ],
        ]]]],
        '401' => ['description' => 'Token invalide'],
    ],
];

$paths['/user/appleAuth']['post'] = [
    'tags'        => ['Auth'],
    'summary'     => 'Connexion / inscription via Apple Sign-In',
    'requestBody' => ['required' => true, 'content' => ['application/json' => ['schema' => [
        'type' => 'object', 'required' => ['identityToken'],
        'properties' => [
            'identityToken' => ['type' => 'string', 'description' => 'Identity Token Apple'],
            'user'          => ['type' => 'string', 'description' => 'Identifiant Apple unique (1er appel seulement)'],
        ],
    ]]]],
    'responses' => [
        '200' => ['description' => 'JWT + user + `isNewAccount`'],
        '401' => ['description' => 'Token invalide'],
    ],
];

// ─── Assemblage ───────────────────────────────────────────────────────────────

ksort($paths);

$seenTags  = [];
$finalTags = [];
foreach ($tags as $t) {
    if (!isset($seenTags[$t['name']])) { $seenTags[$t['name']] = true; $finalTags[] = $t; }
}

$spec['tags']  = $finalTags;
$spec['paths'] = $paths;

echo json_encode($spec, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
